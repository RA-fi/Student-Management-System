﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Gwit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int mov, movX, movY;

        private void label1_DoubleClick(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
                button2.BackgroundImage = Gwit.Properties.Resources.max_01;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
                button2.BackgroundImage = Gwit.Properties.Resources.icons8_maximize_window_64;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
                button2.BackgroundImage = Gwit.Properties.Resources.max_01;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
                button2.BackgroundImage = Gwit.Properties.Resources.icons8_maximize_window_64;


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;

        }

        private void label1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1)
            {
                this.SetDesktopLocation(MousePosition.X - movX,MousePosition.Y - movY);
                if (this.DesktopLocation.Y == 0)
                {
                    this.WindowState = FormWindowState.Maximized;
                    button2.BackgroundImage = Gwit.Properties.Resources.max_01;
                }
                else
                {
                    this.WindowState = FormWindowState.Normal;
                    button2.BackgroundImage = Gwit.Properties.Resources.icons8_maximize_window_64;
                }

            }
        }

        private void label1_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            if (this.student_info1.Visible==false)
            {
                //this.student_info1.Visible = true;
                bunifuTransition2.HideSync(admin1);
                bunifuTransition2.HideSync(api_sms1);
                bunifuTransition2.HideSync(search1);
                bunifuTransition1.ShowSync(student_info1);
            }
            else
            {
                this.search1.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (this.search1.Visible == false)
            {   
                //this.search1.Visible = true;
                bunifuTransition2.HideSync(admin1);
                bunifuTransition2.HideSync(api_sms1);
                bunifuTransition2.HideSync(student_info1);
                bunifuTransition1.ShowSync(search1);
            }
            else
            {
                this.search1.Visible = false;
            }
        }

        private void tableLayoutPanel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            if (this.api_sms1.Visible == false)
            {
                //this.search1.Visible = true;
                bunifuTransition2.HideSync(admin1);
                bunifuTransition2.HideSync(search1);
                bunifuTransition2.HideSync(student_info1);
                bunifuTransition1.ShowSync(api_sms1);
            }
            else
            {
                this.api_sms1.Visible = false;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            if (this.admin1.Visible == false)
            {
                //this.search1.Visible = true;
                bunifuTransition2.HideSync(api_sms1);
                bunifuTransition2.HideSync(student_info1);
                bunifuTransition2.HideSync(search1);
                bunifuTransition1.ShowSync(admin1);

            }
            else
            {
                this.admin1.Visible = false;
            }

        }

        private void label5_Click(object sender, EventArgs e)
        {
            if (this.search1.Visible == false)
            {
                //this.search1.Visible = true;
                bunifuTransition2.HideSync(admin1);
                bunifuTransition2.HideSync(api_sms1);
                bunifuTransition2.HideSync(student_info1);
                bunifuTransition1.ShowSync(search1);
            }
            else
            {
                this.search1.Visible = false;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            bunifuTransition2.HideSync(admin1);
            bunifuTransition2.HideSync(api_sms1);
            bunifuTransition2.HideSync(student_info1);
            bunifuTransition1.HideSync(search1);

        }

        
      
        

       

       

        

       
        

      
       
    }
}
