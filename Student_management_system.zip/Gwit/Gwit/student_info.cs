﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Imaging;

namespace Gwit
{
    public partial class student_info : UserControl
    {
        public student_info()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog opn = new OpenFileDialog();
            opn.Filter = "Chose Image(*.jpg;*.png;*.jpeg;*gif)|*.jpg;*.png;*.jpeg;*gif";
            if (opn.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(opn.FileName);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (pictureBox1.Image == null || textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || comboBox1.Text == "" || comboBox2.Text == "" || comboBox3.Text == "")
            {
                MessageBox.Show("Plese fill up all data on this from");
            }
            else
            {
                cls_connection C = new cls_connection();
                C.Mcon();
                C.cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = C.cn;
                cmd.CommandText = "insert into tbl_student_information(s_name,f_name,m_name,f_phone,roll,dep,semester,shift,phone,image)Values(@s_name,@f_name,@m_name,@f_phone,@roll,@dep,@semester,@shift,@phone,@image)";
                cmd.Parameters.AddWithValue("@s_name", textBox1.Text);
                cmd.Parameters.AddWithValue("@f_name", textBox2.Text);
                cmd.Parameters.AddWithValue("@m_name", textBox3.Text);
                cmd.Parameters.AddWithValue("@f_phone", textBox4.Text);
                cmd.Parameters.AddWithValue("@roll", textBox5.Text);
                cmd.Parameters.AddWithValue("@dep", comboBox1.Text);
                cmd.Parameters.AddWithValue("@semester", comboBox2.Text);
                cmd.Parameters.AddWithValue("@shift", comboBox3.Text);
                cmd.Parameters.AddWithValue("@phone", textBox6.Text);


                MemoryStream ms = new MemoryStream();
                pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
                byte[] photo = ms.ToArray();
                cmd.Parameters.AddWithValue("@image", photo);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully Inserted");

                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                comboBox1.Text = "";
                comboBox2.Text = "";
                comboBox3.Text = "";
                pictureBox1.Image = null;
            }
                
        }

        private void button5_Click(object sender, EventArgs e)
        {
            cls_connection C = new cls_connection();
            C.Mcon();
            C.cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = C.cn;
            cmd.CommandText = "select id as 'Id',s_name as 'User Name',f_name as 'Father Name',m_name as 'Mother Name',f_phone as 'Father Phone',roll as 'Roll',dep as 'Department',semester as 'Semester',shift as 'Shift',phone as'Phone',image as 'Image'  from tbl_student_information";
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void tableLayoutPanel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            byte[] img = (byte[])dataGridView1.CurrentRow.Cells[10].Value;
            MemoryStream ms = new MemoryStream(img);
            pictureBox3.Image = Image.FromStream(ms);

            textBox7.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox8.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox9.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox10.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox11.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            textBox12.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            textBox13.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            textBox14.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            textBox15.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            textBox16.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            pictureBox1.Image = null;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = null;
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
            textBox13.Text = "";
            textBox14.Text = "";
            textBox15.Text = "";
            textBox16.Text = "";

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

      

        private void textBox17_TextChanged(object sender, EventArgs e)
        {
            cls_connection C = new cls_connection();
            C.Mcon();
            C.cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = C.cn;

            cmd.CommandText = "select id as  'Id',s_name as 'User Name',f_name as 'Father Name',m_name as 'Mother Name',f_phone as 'Father Phone',roll as 'Roll',dep as 'Department',semester as 'Semester',shift as 'Shift',phone as'Phone',image as 'Image' from tbl_student_information where roll= '" + textBox17.Text + "' ";
      
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];


        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            cls_connection C = new cls_connection();
            C.Mcon();
            C.cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = C.cn;

            cmd.CommandText = "select id as  'Id',s_name as 'User Name',f_name as 'Father Name',m_name as 'Mother Name',f_phone as 'Father Phone',roll as 'Roll',dep as 'Department',semester as 'Semester',shift as 'Shift',phone as'Phone',image as 'Image' from tbl_student_information where dep= '" + comboBox4.Text + "' ";

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            cls_connection C = new cls_connection();
            C.Mcon();
            C.cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = C.cn;

            cmd.CommandText = "select id as  'Id',s_name as 'User Name',f_name as 'Father Name',m_name as 'Mother Name',f_phone as 'Father Phone',roll as 'Roll',dep as 'Department',semester as 'Semester',shift as 'Shift',phone as'Phone',image as 'Image' from tbl_student_information where semester= '" + comboBox5.Text + "' ";

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            cls_connection C = new cls_connection();
            C.Mcon();
            C.cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = C.cn;

            cmd.CommandText = "select id as  'Id',s_name as 'User Name',f_name as 'Father Name',m_name as 'Mother Name',f_phone as 'Father Phone',roll as 'Roll',dep as 'Department',semester as 'Semester',shift as 'Shift',phone as'Phone',image as 'Image' from tbl_student_information where shift= '" + comboBox6.Text + "' ";

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

       

       
       

        
    }
}
