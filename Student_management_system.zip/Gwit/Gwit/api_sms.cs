﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Imaging;
using System.Net;
using System.Collections.Specialized;


namespace Gwit
{
    public partial class api_sms : UserControl
    {
        public api_sms()
        {
            InitializeComponent();
        }

        private void textBox17_TextChanged(object sender, EventArgs e)
        {
            cls_connection C = new cls_connection();
            C.Mcon();
            C.cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = C.cn;

            cmd.CommandText = "select id as  'Id',s_name as 'User Name',f_name as 'Father Name',m_name as 'Mother Name',f_phone as 'Father Phone',roll as 'Roll',dep as 'Department',semester as 'Semester',shift as 'Shift',phone as'Phone',image as 'Image' from tbl_student_information where roll= '" + textBox17.Text + "' ";

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];


        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            cls_connection C = new cls_connection();
            C.Mcon();
            C.cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = C.cn;

            cmd.CommandText = "select id as  'Id',s_name as 'User Name',f_name as 'Father Name',m_name as 'Mother Name',f_phone as 'Father Phone',roll as 'Roll',dep as 'Department',semester as 'Semester',shift as 'Shift',phone as'Phone',image as 'Image' from tbl_student_information where dep= '" + comboBox4.Text + "' ";

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            cls_connection C = new cls_connection();
            C.Mcon();
            C.cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = C.cn;

            cmd.CommandText = "select id as  'Id',s_name as 'User Name',f_name as 'Father Name',m_name as 'Mother Name',f_phone as 'Father Phone',roll as 'Roll',dep as 'Department',semester as 'Semester',shift as 'Shift',phone as'Phone',image as 'Image' from tbl_student_information where semester= '" + comboBox5.Text + "' ";

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            cls_connection C = new cls_connection();
            C.Mcon();
            C.cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = C.cn;

            cmd.CommandText = "select id as  'Id',s_name as 'User Name',f_name as 'Father Name',m_name as 'Mother Name',f_phone as 'Father Phone',roll as 'Roll',dep as 'Department',semester as 'Semester',shift as 'Shift',phone as'Phone',image as 'Image' from tbl_student_information where shift= '" + comboBox6.Text + "' ";

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
        }

        private void button4_Click(object sender, EventArgs e)
        {
            cls_connection C = new cls_connection();
            C.Mcon();
            C.cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = C.cn;
            cmd.CommandText = "select id as 'Id',s_name as 'User Name',f_name as 'Father Name',m_name as 'Mother Name',f_phone as 'Father Phone',roll as 'Roll',dep as 'Department',semester as 'Semester',shift as 'Shift',phone as'Phone',image as 'Image'  from tbl_student_information";
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            number.Text = "";
            txtMessage.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //https://api.txtlocal.com/docs/sendsms
            String result;
            string _apiKey = "EMyRQRsQAl8-EUXuWpu7ZDTwFCV8L9nmNaKdKpXUDm";
            string _numbers = number.Text; // in a comma seperated list
            string _message = txtMessage.Text;
            string _sender = "Pro Rafi";
            String url = "https://api.txtlocal.com/send/?apikey=" + _apiKey + "&numbers=" + _numbers + "&message=" + _message + "&sender=" + _sender;
            //refer to parameters to complete correct url string

            StreamWriter myWriter = null;
            HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

            objRequest.Method = "POST";
            objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
            objRequest.ContentType = "application/x-www-form-urlencoded";
            try
            {
                myWriter = new StreamWriter(objRequest.GetRequestStream());
                myWriter.Write(url);
            }
            catch (Exception ex)
            {
                MessageBox.Show("This is an Error " + ex.Message);
            }
            finally
            {
                myWriter.Close();
            }
            HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
            using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
            {
                result = sr.ReadToEnd();
                // Close and clean up the StreamReader
                sr.Close();
            }
            //return result;
            MessageBox.Show(result);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String no = null;
            for (int i = 0; i < dataGridView2.RowCount; i++)
            {
                no += dataGridView2.Rows[i].Cells[9].Value + ",";
            }
            number.Text = no;
        }
    }
}
