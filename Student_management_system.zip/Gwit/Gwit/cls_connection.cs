﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace Gwit
{
    class cls_connection
    {
        public SqlConnection cn;
        public void Mcon()
        {
            cn = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=gwit_api;Integrated Security=True;Pooling=False");
        }
    }
}
